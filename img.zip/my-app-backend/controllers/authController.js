const User = require('../models/userModel');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// Genera il token JWT
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: '30d',
  });
};

// Funzione per validare i campi della richiesta
const validateUserInput = (username, email, password) => {
  if (!username || !email || !password) {
    return 'Please provide all fields (username, email, password)';
  }
  if (password.length < 6) {
    return 'Password must be at least 6 characters long.';
  }
  return null;
};

// Registrazione utente
exports.registerUser = async (req, res, next) => {
  try {
    const { username, email, password } = req.body;

    // Validazione dei campi della richiesta
    const validationError = validateUserInput(username, email, password);
    if (validationError) {
      return res.status(400).json({ message: validationError });
    }

    // Controlla se l'utente o l'email esistono già
    const userExists = await User.findOne({ $or: [{ username }, { email }] });

    if (userExists) {
      return res.status(400).json({ message: 'User already exists with this username or email' });
    }

    // Hash della password
    const trimmedPassword = password.trim();
    const hashedPassword = await bcrypt.hash(trimmedPassword, 10);

    // Verifica che la password sia stata hashata correttamente
    console.log('Password hashata durante la registrazione:', hashedPassword);

    // Crea il nuovo utente con la password criptata
    const user = await User.create({ username, email, password: hashedPassword });

    if (!user) {
      return res.status(400).json({ message: 'User creation failed.' });
    }

    // Verifica che la password hashata salvata nel database sia la stessa
    const savedUser = await User.findOne({ username });
    console.log('Password hashata nel database dopo salvataggio:', savedUser.password);

    // Risposta con il token JWT
    res.status(201).json({
      _id: savedUser._id,
      username: savedUser.username,
      email: savedUser.email,
      token: generateToken(savedUser._id),
    });
  } catch (error) {
    console.error('Errore durante la registrazione:', error);
    next(error);
  }
};

// Login utente
exports.loginUser = async (req, res, next) => {
  try {
    const { username, password } = req.body;

    // Validazione dei campi della richiesta
    if (!username || !password) {
      return res.status(400).json({ message: 'Please provide both username and password.' });
    }

    // Trova l'utente in base al nome utente
    const user = await User.findOne({ username });

    if (!user) {
      console.log("Utente non trovato");
      return res.status(401).json({ message: 'Invalid username or password' });
    }

    // Stampa la password hashata memorizzata nel database
    console.log('Password hashata nel database:', user.password);

    // Trim della password inserita per evitare spazi bianchi involontari
    const trimmedPassword = password.trim();

    // Confronta manualmente la password
    const isPasswordMatch = await bcrypt.compare(trimmedPassword, user.password);

    // Log per verificare il confronto delle password
    console.log('Password inserita (dopo trim):', trimmedPassword);
    console.log('Risultato del confronto:', isPasswordMatch);

    if (!isPasswordMatch) {
      console.log("Password non corrisponde");
      return res.status(401).json({ message: 'Invalid username or password' });
    }

    // Se l'autenticazione ha successo
    console.log("Login avvenuto con successo");
    res.json({
      _id: user._id,
      username: user.username,
      email: user.email,
      token: generateToken(user._id),
    });
  } catch (error) {
    console.error('Errore durante il login:', error);
    next(error);
  }
};

// Reset della password
exports.resetPassword = async (req, res, next) => {
  try {
    const { username } = req.body;

    // Trova l'utente in base al nome utente
    const user = await User.findOne({ username });

    if (!user) {
      return res.status(400).json({ message: 'User not found' });
    }

    // Genera una nuova password casuale
    const newPassword = Math.random().toString(36).slice(-8);

    // Hash della nuova password
    const hashedNewPassword = await bcrypt.hash(newPassword.trim(), 10);

    // Verifica che la nuova password sia stata hashata correttamente
    console.log('Nuova password hashata:', hashedNewPassword);

    // Salva la nuova password hashata nel database
    user.password = hashedNewPassword;
    await user.save();

    // Risposta con la nuova password generata
    res.json({ message: `New password generated: ${newPassword}` });
  } catch (error) {
    console.error('Errore durante il reset della password:', error);
    next(error);
  }
};
