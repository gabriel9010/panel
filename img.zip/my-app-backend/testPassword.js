// testPassword.js

const bcrypt = require('bcryptjs');

// Copia l'hash memorizzato nel database dal log del server
const storedHash = '$2a$10$lHnFvC9K3rcu6YIcNIHxieREjiNrOItbDQx79Rgjq46PQmMjTVMAi';

// La password in chiaro che l'utente inserisce
const inputPassword = 'Fiokko@12@';

// Confronta manualmente la password in chiaro con l'hash
bcrypt.compare(inputPassword, storedHash, (err, isMatch) => {
  if (err) {
    console.error('Errore durante il confronto:', err);
  } else if (isMatch) {
    console.log('Password corretta');
  } else {
    console.log('Password errata');
  }
});
